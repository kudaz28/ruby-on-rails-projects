require 'test_helper'

class NewslettersTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
