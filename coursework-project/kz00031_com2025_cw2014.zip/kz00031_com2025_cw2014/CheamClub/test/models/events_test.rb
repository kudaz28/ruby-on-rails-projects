require 'test_helper'

class EventsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
