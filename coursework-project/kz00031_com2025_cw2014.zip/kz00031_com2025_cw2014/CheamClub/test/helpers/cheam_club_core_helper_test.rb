require 'test_helper'

class CheamClubCoreHelperTest < ActionView::TestCase
end
