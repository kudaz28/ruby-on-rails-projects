require 'test_helper'

class EventsHelperTest < ActionView::TestCase
end
