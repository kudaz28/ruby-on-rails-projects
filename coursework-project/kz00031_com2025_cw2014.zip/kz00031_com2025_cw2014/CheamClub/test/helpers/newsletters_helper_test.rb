require 'test_helper'

class NewslettersHelperTest < ActionView::TestCase
end
